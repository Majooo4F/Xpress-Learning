const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { query } = require('../config/db');
const logger = require('../utils/logger');

exports.getClase = async (req, res) => {
    // Implementacion para el GET /clase/
    try{
        
        const result =  await query('SELECT * FROM CLASES');
        res.status(200).json(result.rows);
        
    } catch (error) {

        logger.error('Error al obtener cursos: ', error);
        res.status(500).json({ error: 'Error al obtener cursos' });

    }
};

exports.getClaseId = async (req, res) => {
    // Implementacion para el GET /clase/{id}
    const { id } = req.params;
    try {
        const result = await query('SELECT * FROM CLASES WHERE ID_CLASE = $1', [id]);
        if(result.rows.length > 0) {
            res.status(200).json(result [0]);
        } else {
            res.status(404).json({ error: 'Clase no encontrada'});
        }
    } catch (error) {

        logger.error('Error al obtener clase por ID: ', error);
        res.status(500).json({ error: 'Error al obtener clase por ID: ' + id });

    }
};

exports.postClase = async (req, res) => {
    // Implementacion para el POST /clase/
    const { nombre, id_profesor, nivel_academico} = req.body;

    try {
        
        const { rows } = await query(
            'INSERT INTO CLASES (NOMBRE, ID_PROFESOR, NIVEL_ACADEMICO) VALUES ($1, $2, $3) RETURNING *',
            [nombre, id_profesor, nivel_academico]
        );

        res.status(201).json(result [0]);

    } catch (error) {
        
        console.error('Error en registrar la calse: ', error);
        res.status(500).json({ error: 'Error interno del servidor'})

    }
};